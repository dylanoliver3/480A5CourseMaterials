#pragma once

extern const char *g_HeatmapColors_HTML[10];
extern const char *g_HeatmapColors_JalView[10];
