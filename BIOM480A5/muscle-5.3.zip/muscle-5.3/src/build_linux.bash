curl -fsSL https://raw.githubusercontent.com/rcedgar/vcxproj_make/806d016/vcxproj_make.py \
  > vcxproj_make.py
chmod +x vcxproj_make.py
./vcxproj_make.py --openmp
