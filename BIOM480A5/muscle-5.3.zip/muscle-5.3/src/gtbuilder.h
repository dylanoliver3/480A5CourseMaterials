#pragma once

#include "gtbnode.h"

class GTBuilder
	{
public:
	uint m_TargetSeedCount = 32;
	uint m_MaxAll = 1024;
	const MultiSequence *m_Seqs = 0;

public:
	};
