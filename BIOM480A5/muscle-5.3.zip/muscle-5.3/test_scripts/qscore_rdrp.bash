../bin/muscle \
  -qscore ../test_output/rdrp/rdrp_seqs.afa \
  -ref ../test_output/rdrp/rdrp_structs.afa \
  -bysequence \
  -log ../test_logs/qscore_rdrp.log
