Please see https://github.com/rcedgar/muscle/wiki/Contributing-to-MUSCLE.
