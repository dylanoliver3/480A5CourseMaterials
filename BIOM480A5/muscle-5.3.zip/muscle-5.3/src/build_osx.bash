rm -f vcxproj_make.py
wget https://raw.githubusercontent.com/rcedgar/vcxproj_make/806d016/vcxproj_make.py
./vcxproj_make.py --openmp --cppcompiler g++-11
