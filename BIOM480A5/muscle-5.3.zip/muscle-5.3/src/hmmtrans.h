#ifndef T
#error "T not defined"
#endif

T(START_M)
T(START_IS)
T(START_IL)

T(M_M)
T(M_IS)
T(M_IL)

T(IS_IS)
T(IS_M)

T(IL_IL)
T(IL_M)

#undef T
