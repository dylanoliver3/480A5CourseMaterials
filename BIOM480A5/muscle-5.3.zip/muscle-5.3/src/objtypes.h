#ifndef T
#error "T not defined"
#endif

T(SeqInfo)
T(PathInfo)

#undef T
