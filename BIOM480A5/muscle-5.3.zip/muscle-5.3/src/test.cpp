#include "muscle.h"
#include "mega.h"

void _cmd_test()
	{
#if 0
	Mega M;
	M.FromFile(g_Arg1);
	const uint FeatureCount = M.GetFeatureCount();
	for (uint i = 0; i < FeatureCount; ++i)
		M.LogFeatureParams(i);
#endif
	}
