#pragma once

extern float g_Viterbi_GapOpen;
extern float g_Viterbi_GapExt;
extern float g_Viterbi_TermGapOpen;
extern float g_Viterbi_TermGapExt;
extern float **g_Viterbi_SubstMx_Char;
