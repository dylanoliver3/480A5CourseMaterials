#include "muscle.h"

void Help()
	{
	PrintBanner(stdout);
	fprintf(stdout,
#include "help.h"
	);
	}
