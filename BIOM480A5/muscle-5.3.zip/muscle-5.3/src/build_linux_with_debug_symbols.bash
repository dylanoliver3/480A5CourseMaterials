./build_linux.py --openmp --symbols
